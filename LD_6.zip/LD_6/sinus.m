function varargout = sinus(varargin)
    global x
    global y
    varargin = x;
    y = sin(varargin)./varargin;
    varargout{1} = y;
end