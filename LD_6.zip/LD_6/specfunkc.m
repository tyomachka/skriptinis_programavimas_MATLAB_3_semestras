function varargout = specfunkc(varargin)

if nargin == 1
    x = varargin{1};
    varargout{1} = x^2;

elseif nargin == 2
    x = varargin{1};
    y = varargin{2};

    x = x^2;
    y = y^3;

    varargout{1} = min(x, y);
end

end