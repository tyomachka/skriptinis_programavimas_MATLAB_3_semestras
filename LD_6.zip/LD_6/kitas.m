function varargout = kitas(varargin)
    global y
    y = 1;
    varargout{1} = y;
end