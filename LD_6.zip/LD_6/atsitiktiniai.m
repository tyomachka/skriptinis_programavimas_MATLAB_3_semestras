function [ATS_did] = atsitiktiniai(e, s, N);
    ATS_did = zeros(e, s);
    for i=1:e
        for j=1:s
            ATS_did(i, j) = ceil(1+(N-1)*rand(1, "single"));
        end
    end
    ATS_did = ATS_did(:);
end