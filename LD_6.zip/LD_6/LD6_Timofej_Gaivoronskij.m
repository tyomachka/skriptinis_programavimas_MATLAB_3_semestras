%% Timofej Gaivoronskij EEF-25/1

%% 1
clc
clear

ATS_did = atsitiktiniai(e, s, N);
fprintf('Sugeneruotas masyvas: ');
disp(ATS_did)

%% 2

clc
clear

global x;
x = 2*pi:-0.1:-2*pi;
global y
if x == 0
    y = kitas;
else
    y = sinus;
end
plot(x, y, 'LineWidth', 1.5);
grid on
xlabel('x');
ylabel('sin(x)');
title('Funkcijos grafikas');
legend('sin(x)');

%% papildoma

clc
clear

a = input('Iveskite pirma skaiciu: ');

pasirinkimas = input('Ar norite ivesti antra skaiciu? 1-taip, 0-ne: ');

if pasirinkimas == 1
    b = input('Iveskite antra skaiciu: ');
    rezultatas = specfunkc(a, b);
else
    rezultatas = specfunkc(a);
end

disp(rezultatas)